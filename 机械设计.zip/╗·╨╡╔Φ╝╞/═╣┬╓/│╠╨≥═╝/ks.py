import numpy as np
import matplotlib.pyplot as plt
from matplotlib.image import imread
import math as m


doc = open('ts.txt','w')
doc2 = open('bs.txt','w')


class TC:
    def __init__(self, ta, h, w, x):
        self.ta = ta
        self.h = h
        self.w = w
        self.x = x

    def gos(self):
        s = self.h * (self.x / self.ta - 1 / (2 * m.pi) * np.sin((2 * m.pi * self.x / self.ta)))
        print(self.x,s,file = doc)
        doc.close()
        return s

    def gov(self):
        v = self.h * self.w /self.ta * (1 - np.cos((2 * m.pi * self.x / self.ta)))
        return v

    def goa(self):
        a = 2 * m.pi * self.h * self.w * self.w / (self.ta * self.ta) * np.sin((2 * m.pi * self.x / self.ta))
        return a


class HC:
    def __init__(self, ha, h, w, x):
        self.ha = ha
        self.h = h
        self.w = w
        self.x = x

    def backs(self):
        s = self.h * (1 - self.x / self.ha + 1 / (2 * m.pi) * np.sin(2 * m.pi / self.ha * self.x))
        print(self.x,s,file = doc2)
        doc2.close()
        return s

    def backv(self):
        v = self.h * self.w / self.ha * (np.cos(2 * m.pi / self.ha * self.x) - 1)
        return v

    def backa(self):
        a = - 2 * m.pi * self.h * self.w * self.w / (self.ha * self.ha) * np.sin(2 * m.pi / self.ha * self.x)
        return a


ta = int(input('输入推程角\n'))
ha = int(input('输入回程角\n'))
h = int(input('输入摆角\n'))
w = int(input('输入角速度\n'))

tx = np.arange(0, ta + 1e-10, 0.5)
hx = np.arange(0, ha + 1e-10, 0.5)

T = TC(ta, h, w, tx)

y_gos = T.gos()
y_gov = T.gov()
y_goa = T.goa()

H = HC(ha, h, w, hx)

y_backs = H.backs()
y_backv = H.backv()
y_backa = H.backa()


plt.figure(1)
plt.plot(tx, y_gos, label="s")
plt.xlabel("rad(CAM)")
plt.ylabel("rad(Swinging rod)")
plt.title('s')
plt.legend()

plt.figure(2)
plt.plot(tx, y_gov, label="v")
plt.xlabel("rad(CAM)")
plt.ylabel("rad/s(Swinging rod)")
plt.title('v')
plt.legend()

plt.figure(3)
plt.plot(tx, y_goa, label="a")
plt.xlabel("rad(CAM)")
plt.ylabel("rad/s2(Swinging rod)")
plt.title('a')
plt.legend()

plt.figure(4)
plt.plot(hx, y_backs, label="s")
plt.xlabel("rad(CAM)")
plt.ylabel("rad(Swinging rod)")
plt.title('s')
plt.legend()

plt.figure(5)
plt.plot(hx, y_backv, label="v")
plt.xlabel("rad(CAM)")
plt.ylabel("rad/s(Swinging rod)")
plt.title('v')
plt.legend()

plt.figure(6)
plt.plot(hx, y_backa, label="a")
plt.xlabel("rad(CAM)")
plt.ylabel("rad/s2(Swinging rod)")
plt.title('a')
plt.legend()

plt.show()
